<?php

use App\Http\Controllers\LoginController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


    Route::post('register', 'AuthController@register');
    Route::post('login', 'AuthController@login');
    Route::get('/login','AuthController@login')->name('login');


    Route::group(['middleware' => 'auth:api'], function () {

        Route::group(['prefix' => 'books'], function () {

            Route::get('list', 'BookController@index');
            Route::post('store', 'BookController@store');
            Route::post('update', 'BookController@update');
            Route::post('show', 'BookController@show');
            Route::post('rented', 'BookController@rentBook');
            Route::post('return', 'BookController@returnBook');
        });

        Route::group(['prefix' => 'user'], function () {

            Route::post('get-rented-bookes', 'BookController@GetRentedBookByUser');

        });

    Route::post('get-profile', 'AuthController@profile');
    Route::post('logout', 'AuthController@logout');


    // bookes route here




    });
