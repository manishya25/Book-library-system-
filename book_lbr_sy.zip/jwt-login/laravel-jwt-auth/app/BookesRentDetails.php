<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookesRentDetails extends Model
{
    protected $fillable = [
        'book_id',
        'user_id',
        'is_return',
    ];

    public function product_bullet_points()
    {
        return $this->hasMany(bookes::class);
    }
}
