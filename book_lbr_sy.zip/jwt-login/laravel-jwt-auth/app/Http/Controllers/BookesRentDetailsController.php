<?php

namespace App\Http\Controllers;

use App\BookesRentDetails;
use Illuminate\Http\Request;

class BookesRentDetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BookesRentDetails  $bookesRentDetails
     * @return \Illuminate\Http\Response
     */
    public function show(BookesRentDetails $bookesRentDetails)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\BookesRentDetails  $bookesRentDetails
     * @return \Illuminate\Http\Response
     */
    public function edit(BookesRentDetails $bookesRentDetails)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BookesRentDetails  $bookesRentDetails
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BookesRentDetails $bookesRentDetails)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BookesRentDetails  $bookesRentDetails
     * @return \Illuminate\Http\Response
     */
    public function destroy(BookesRentDetails $bookesRentDetails)
    {
        //
    }
}
