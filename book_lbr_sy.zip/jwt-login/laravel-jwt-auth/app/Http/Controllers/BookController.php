<?php

namespace App\Http\Controllers;

use App\bookes;
use App\BookesRentDetails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpFoundation\Response;

class BookController extends Controller
{

    public function index()
    {

        $all_books = bookes::all();

        return response()->json([
            'success' => true,
            'message' => 'books Fetch successfully',
            'data' => $all_books
        ], Response::HTTP_OK);


    }

    public function store(Request $request)
    {

        //Validate data
        $data = $request->only('book_name', 'author', 'cover_image');
        $validator = Validator::make($data, [
            'book_name' => 'required|string|unique:bookes',
            'author' => 'required',
            'cover_image' => 'required'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['error' => $validator->messages()], 200);
        }

        $book = bookes::create([
            'book_name'=>$request->book_name,
            'author'=>$request->author,
            'cover_image'=>$request->cover_image
        ]);

       // created, return success response

        return response()->json([
            'success' => true,
            'message' => 'book created successfully',
            'data' => $book
        ], Response::HTTP_OK);


    }

    public function update(Request $request)
    {
        $data = $request->only('id','book_name', 'author', 'cover_image');
        $validator = Validator::make($data, [
            'book_name' => 'required|string',
            'author' => 'required',
            'cover_image' => 'required',
            'id'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['error' => $validator->messages()], 200);
        }


        $bookes_update = bookes::where('b_id',$request->id)->update([
            'book_name' => $request->book_name,
            'author' => $request->author,
            'cover_image' => $request->cover_image
        ]);

        //bookes updated, return success response
        return response()->json([
            'success' => true,
            'message' => 'book updated successfully',
            'data' => $bookes_update
        ], Response::HTTP_OK);


    }

    public function destroy($id)
    {
        //
    }

    public function rentBook(Request $request)
    {

        //Validate data
        $data = $request->only('book_id',  'user_id');
        $validator = Validator::make($data, [
            'book_id' => 'required',
            'user_id' => 'required'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['error' => $validator->messages()], 200);
        }

        $is_book_present = bookes::where('b_id',$request->book_id)->first();

        if(is_null($is_book_present)){

            return response()->json([
                'success' => true,
                'message' => 'this bookes not avilable',
                'data' => $data
            ], Response::HTTP_OK);

        }


        $bookDetails = BookesRentDetails::create([
            'book_id' => $request->book_id,
            'user_id' => $request->user_id,
            'is_return'=>0
        ]);

        // created, return success response

        return response()->json([
            'success' => true,
            'message' => 'rented successfully',
            'data' => $bookDetails
        ], Response::HTTP_OK);


    }

    public function returnBook(Request $request)
    {

        //Validate data
        $data = $request->only('book_id',  'user_id');
        $validator = Validator::make($data, [
            'book_id' => 'required',
            'user_id' => 'required'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['error' => $validator->messages()], 200);
        }

       $data_update = BookesRentDetails::where('book_id',$request->book_id)->update([
            'is_return'=>1
        ]);



        // created, return success response

        return response()->json([
            'success' => true,
            'message' => 'return successfully',
            'data' => $data
        ], Response::HTTP_OK);


    }

    public function GetRentedBookByUser(Request $request){

        $data = $request->only( 'user_id');
        $validator = Validator::make($data, [
            'user_id' => 'required'
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            return response()->json(['error' => $validator->messages()], 200);
        }

       $data = BookesRentDetails::select([
           'bookes_rent_details.id as id',
           'users.id as user_id',
           'users.firstname as firstname',
           'bookes.book_name as book_name',
           'bookes.b_id as b_id',
           'bookes_rent_details.is_return as is_return',
       ])->leftJoin('users', 'users.id', '=', 'bookes_rent_details.user_id')
           ->leftJoin('bookes', 'bookes.b_id', '=', 'bookes_rent_details.book_id')
           ->where('user_id',$request->user_id)->get()->toArray();


        return response()->json([
            'success' => true,
            'message' => 'data fetched successfully',
            'data' => $data
        ], Response::HTTP_OK);

    }
}
